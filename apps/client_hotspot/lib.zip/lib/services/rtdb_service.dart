import 'dart:async';
import 'package:firebase_database/firebase_database.dart';
import 'dart:developer' as developer;

class RtdbService {
  final DatabaseReference _dbRef = FirebaseDatabase.instance.ref();

  Stream<Map<String, dynamic>> getQuotaStream(String userId) {
    final stream = _dbRef.child('users/$userId/quota').onValue.map((event) {
      try {
        final data = event.snapshot.value as Map<dynamic, dynamic>?;
        if (data != null) {
          // Konversi data ke Map<String, dynamic> yang lebih aman
          return data.map((key, value) => MapEntry(key.toString(), value));
        } else {
          return {}; // Kembalikan map kosong jika tidak ada data
        }
      } catch (e, stackTrace) {
        // Gunakan logger untuk error parsing data
        developer.log(
          'Error parsing RTDB data',
          name: 'RtdbService',
          error: e,
          stackTrace: stackTrace,
          level: 1000, // SEVERE
        );
        // Lemparkan kembali error agar bisa ditangani oleh StreamBuilder
        rethrow;
      }
    });

    // Gunakan StreamTransformer untuk menangani error pada stream itu sendiri (cth: permission denied)
    return stream.transform(StreamTransformer.fromHandlers(
      handleError: (error, stackTrace, sink) {
        developer.log(
          'Error on RTDB stream',
          name: 'RtdbService',
          error: error,
          stackTrace: stackTrace,
          level: 1000, // SEVERE
        );
        // Teruskan error ke listener (StreamBuilder)
        sink.addError(error, stackTrace);
      },
    ));
  }
}
