// lib/models/quota_model.dart

class Quota {
  final String nama;
  final double total;
  final double sisa;
  final String validUntil;

  // --- Computed Properties ---
  // Properti ini tidak disimpan di database, tetapi dihitung secara real-time.

  /// Menghitung jumlah kuota yang telah digunakan.
  double get digunakan => total - sisa;

  /// Menghitung persentase sisa kuota (nilai antara 0.0 hingga 1.0).
  /// Berguna untuk progress bar atau indikator lingkaran.
  double get persentaseSisa {
    if (total <= 0) {
      return 0.0; // Menghindari pembagian dengan nol dan nilai negatif
    }
    return sisa / total;
  }
  
  /// Menghitung persentase sisa kuota dalam format 0-100.
  int get persentaseSisaInt => (persentaseSisa * 100).round();


  /// Memeriksa apakah kuota akan segera habis (misalnya, di bawah 10%).
  bool get isNearlyEmpty => persentaseSisa < 0.1 && sisa > 0;

  // --- Constructor ---
  Quota({
    required this.nama,
    required this.total,
    required this.sisa,
    required this.validUntil,
  });

  // --- Factory Constructor ---
  // Ini adalah "pabrik" yang mengubah data mentah dari Firebase (Map)
  // menjadi objek Quota yang terstruktur dan aman.

  factory Quota.fromMap(Map<String, dynamic> map) {
    return Quota(
      // Menggunakan ?? untuk memberikan nilai default jika data tidak ada (null).
      nama: map['nama'] as String? ?? 'Paket Tidak Dikenal',
      
      // Mengonversi 'num' (bisa int atau double) menjadi double.
      // Memberikan nilai 0.0 jika null atau terjadi error.
      total: (map['total'] as num?)?.toDouble() ?? 0.0,
      sisa: (map['sisa'] as num?)?.toDouble() ?? 0.0,

      validUntil: map['valid_until'] as String? ?? 'N/A',
    );
  }
  
  // Method untuk membuat Quota kosong sebagai state awal atau saat error
  static Quota empty() {
    return Quota(
      nama: 'Memuat...',
      total: 1, // Menggunakan 1 untuk menghindari pembagian dengan 0 di UI
      sisa: 0,
      validUntil: '...'
    );
  }
}
